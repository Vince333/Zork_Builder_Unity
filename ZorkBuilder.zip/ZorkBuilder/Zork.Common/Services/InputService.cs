﻿using System;

namespace Zork
{
    public interface InputService
    {
        event EventHandler<string> InputReceived;
    }
}
